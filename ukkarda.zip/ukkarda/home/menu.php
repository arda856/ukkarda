        <?php 
        $akses = $_SESSION['hak_akses'];
        $id = $_SESSION['id_admin'];
        $data = mysqli_query($koneksi, "SELECT * FROM tb_admin WHERE id_admin=$id");
        $row = mysqli_fetch_assoc($data);
        ?>

        <?php if ($akses == "admin") { ?>
        <nav class="page-sidebar" id="sidebar">
            <div id="sidebar-collapse">
                <div class="admin-block d-flex">
                    <div>
                        
                    </div>
                    <div class="admin-info">
                        <div class="font-strong"><?php echo $_SESSION['nama_admin']; ?></div><small><?php echo $_SESSION['hak_akses']; ?></small></div>
                </div>
                <ul class="side-menu metismenu">
                    <li>
                        <a class="active" href="index.php"><i class=""></i>
                            <span class="nav-label">Dashboard</span>
                        </a>
                    </li>
                    
                        </ul>
                    </li>
                    <li>
                        <a href="peminjaman.php"><i class=""></i>
                            <span class="nav-label">Peminjaman Buku</span></a>
                    </li>
                    <li>
                        <a href="riwayat.php"><i class=""></i>
                            <span class="nav-label">Riwayat</span></a>
                    </li>
                    <li>
                        <a href="admin.php"><i class=""></i>
                            <span class="nav-label">laporan</span></a>
                    </li>
                    
                        </ul>
                    </li>
                    <li>
                        <a href="keluar.php"><i class=""></i>
                            <span class="nav-label">Keluar</span></a>
                    </li>
                </ul>
            </div>
        </nav>
    <?php }elseif ($akses == "user") { ?>
        <nav class="page-sidebar" id="sidebar">
            <div id="sidebar-collapse">
                <div class="admin-block d-flex">
                    <div>
                        <img src="<?php echo $row['foto']; ?>" width="45px" />
                    </div>
                    <div class="admin-info">
                        <div class="font-strong"><?php echo $_SESSION['nama_admin']; ?></div><small><?php echo $_SESSION['hak_akses']; ?></small></div>
                </div>
                <ul class="side-menu metismenu">
                    <li>
                        <a class="active" href="index.html"><i class=""></i>
                            <span class="nav-label">Dashboard</span>
                        </a>
                    </li>
                    <li class="heading">Peminjaman Buku</li>
                    <li>
                        <a href="peminjaman.php"><i class=""></i>
                            <span class="nav-label">Peminjaman Buku</span></a>
                    </li>
                    <li>
                        <a href="riwayat.php"><i class=""></i>
                        
                    </li>
                    <li class="heading">Lainnya</li>
                    <li>
                        <a href="javascript:;"><i class=""></i>
                            <span class="nav-label">Laporan</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="laporanP.php"><i class="fa fa-file"></i> Laporan Peminjaman</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="keluar.php"><i class=""></i>
                            <span class="nav-label">Keluar</span></a>
                    </li>
                </ul>
            </div>
        </nav>
        <?php } ?>