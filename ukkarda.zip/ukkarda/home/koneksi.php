<?php 
$host = "localhost";
$user = "root";
$pass = "";
$db = "dbpeminjamanbuku";

$koneksi = New mysqli($host, $user, $pass, $db);
?>